#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float num1, num2, resultado;
	int opcao;
	
	printf("Digite o primeiro numero: \n");
	scanf("%f", &num1);
	
	printf("Digite o segundo numero: \n");
	scanf("%f", &num2);
	
	printf("\n--- Menu de Operacoes ---\n");
	printf("Escolha uma opcao (1-4): \n");
    printf("1. Somar\n");
    printf("2. Subtrair\n");
    printf("3. Multiplicar\n");
    printf("4. Dividir\n");
    scanf("%d", &opcao);
    
    switch (opcao){
    	case 1:
    		resultado = num1 + num2;
    		printf("Resultado da Soma: %.2f\n", resultado);
    		break;
    	
    	case 2:
    		resultado = num1 - num2;
    		printf("Resultado da subtracao; %.2f\n", resultado);
    		break;
    		
    	case 3:
    		resultado = num1 * num2;
    		printf("Resultado da Multiplicacao: %.2f\n", resultado);
    		break;
    		
    	case 4:
			if (num2 == 0){
				printf("Erro: Nao e possivel dividir por zero!\n");
			}else {
				resultado = num1 / num2;
				printf("Resultado da Divisao: %.2f", resultado);
			}
			break;
			default:
				printf("Opcao invalida! Escolha um numero de 1 a 4.\n");
				break;
				
	}
	return 0;
}
