#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	 int senha;
    int senhaCorreta = 1234;
    int tentativas = 0;

    while (tentativas < 3) {

        printf("Digite a senha: ");
        scanf("%d", &senha);

        tentativas++;

        if (senha == senhaCorreta) {
            printf("Acesso autorizado!\n");
            return 0;
        } else {
            printf("Senha incorreta!\n");
        }
    }

    printf("Usuario bloqueado!\n");
	return 0;
}
