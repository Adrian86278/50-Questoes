#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int numeros[10];
    int i, x, encontrado = 0;

    for (i = 0; i < 10; i++) {
        printf("Digite o %do numero: ", i + 1);
        scanf("%d", &numeros[i]);
    }

    printf("\nDigite o numero que deseja buscar (X): ");
    scanf("%d", &x);

    printf("\nResultado da busca:\n");
    for (i = 0; i < 10; i++) {
        if (numeros[i] == x) {
            printf("Encontrado no indice %d (%da posicao)\n", i, i + 1);
            encontrado = 1;
        }
    }

    if (!encontrado) {
        printf("O numero %d nao foi encontrado no vetor.\n", x);
    }
	return 0;
}
