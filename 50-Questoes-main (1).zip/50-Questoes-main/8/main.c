#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float num1, num2, num3;
	
	printf("====Digite tres numeros e descubra qual o maior entre eles!====\n");
	printf("Digite o primeiro numero: ");
	scanf("\n%d", &num1);
	printf("Digite o segundo numero: ");
	scanf("\n%d", &num2);
	printf("Digite o terceiro numero: ");
	scanf("\n%d", &num3);
	
	if(num1 >= num2 && num1 >= num3){
		printf("O primeiro numero e o maior!");
	} else if (num2 >= num1 && num2 >= num3){
		printf("O segundo numero e o maior!");
	} else {
		printf("O terceiro numero e o maior!");
	}
	
	
	
	return 0;
}
