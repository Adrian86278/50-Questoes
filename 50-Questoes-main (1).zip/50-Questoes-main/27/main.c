#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
int numeros[10];
    int i, maior, menor, posMaior = 0, posMenor = 0;

    for (i = 0; i < 10; i++) {
        printf("Digite o %do numero: ", i + 1);
        scanf("%d", &numeros[i]);
    }

    maior = numeros[0];
    menor = numeros[0];

    for (i = 1; i < 10; i++) {
        if (numeros[i] > maior) {
            maior = numeros[i];
            posMaior = i;
        }

        if (numeros[i] < menor) {
            menor = numeros[i];
            posMenor = i;
        }
    }

    printf("\nMaior valor: %d (indice %d / %da posicao)\n", maior, posMaior, posMaior + 1);
    printf("Menor valor: %d (indice %d / %da posicao)\n", menor, posMenor, posMenor + 1);
	return 0;
}
