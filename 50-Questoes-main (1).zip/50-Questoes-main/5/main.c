#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	    int num;

    
    printf("Digite um numero: ");
    scanf("%d", &num);

    
   if (num > 0) {
        printf("Positivo.\n", num);
    } 
    else if (num < 0) {
        printf("Negativo.\n", num);
    } 
    else {
        printf("igual a Zero.\n", num);
    }
	return 0;
}
