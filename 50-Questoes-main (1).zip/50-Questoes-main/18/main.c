#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int N, i;
    int soma = 0;

    printf("Digite um numero inteiro positivo (N): ");
    scanf("%d", &N);

    if (N <= 0) {
        printf("Por favor, digite um numero maior que zero.\n");
    } else {
 
        for (i = 1; i <= N; i++) { 
        	soma += i;
        }
        printf("A soma de todos os numeros entre 1 e %d e: %d\n", N, soma);
    }
	
	return 0;
}
