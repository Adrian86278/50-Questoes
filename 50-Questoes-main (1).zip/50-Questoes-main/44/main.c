#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float somar(float a, float b);
float subtrair(float a, float b);
float multiplicar(float a, float b);
float dividir(float a, float b);

int main() {
    int opcao;
    float num1, num2;

    do {
        printf("\n=== CALCULADORA MODULAR ===\n");
        printf("1 - Soma\n");
        printf("2 - Subtracao\n");
        printf("3 - Multiplicacao\n");
        printf("4 - Divisao\n");
        printf("0 - Sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        if (opcao >= 1 && opcao <= 4) {
            printf("Digite o primeiro numero: ");
            scanf("%f", &num1);
            printf("Digite o segundo numero: ");
            scanf("%f", &num2);
        }

        switch (opcao) {
            case 1:
                printf("Resultado: %.2f\n", somar(num1, num2));
                break;
            case 2:
                printf("Resultado: %.2f\n", subtrair(num1, num2));
                break;
            case 3:
                printf("Resultado: %.2f\n", multiplicar(num1, num2));
                break;
            case 4:
                if (num2 == 0) {
                    printf("Erro: divisao por zero nao permitida!\n");
                } else {
                    printf("Resultado: %.2f\n", dividir(num1, num2));
                }
                break;
            case 0:
                printf("Encerrando a calculadora...\n");
                break;
            default:
                printf("Opcao invalida! Tente novamente.\n");
        }
    } while (opcao != 0);

    return 0;
}

float somar( a,  b) {
    return a + b;
}

float subtrair(float a, float b) {
    return a - b;
}

float multiplicar(float a, float b) {
    return a * b;
}

float dividir(float a, float b) {
    return a / b;
}
	return 0;
}
