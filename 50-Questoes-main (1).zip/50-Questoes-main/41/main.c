
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int numeroSecreto, palpite, tentativas = 0;

    // Inicializa o gerador de n�meros aleat�rios com base na hora atual
    srand(time(NULL));

    // Sorteia um n�mero entre 1 e 100
    numeroSecreto = (rand() % 100) + 1;

    printf("=== JOGO DE ADIVINHACAO ===\n");
    printf("Tente adivinhar o numero secreto entre 1 e 100.\n\n");

    do {
        printf("Digite o seu palpite: ");
        scanf("%d", &palpite);
        tentativas++;

        if (palpite < numeroSecreto) {
            printf("O numero secreto e MAIOR!\n\n");
        } else if (palpite > numeroSecreto) {
            printf("O numero secreto e MENOR!\n\n");
        } else {
            printf("\nParabens! Acertou no numero %d em %d tentativa(s)!\n", numeroSecreto, tentativas);
        }

    } while (palpite != numeroSecreto);

    return 0;
}

