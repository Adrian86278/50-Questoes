#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {int N, i;
    unsigned long long fatorial = 1; // Inicializa com 1 para multiplica��es

    printf("Digite um numero inteiro nao negativo: ");
    scanf("%d", &N);

    if (N < 0) {
        printf("Erro: Nao existe fatorial de numero negativo!\n");
    } else {
      
        for (i = 1; i <= N; i++) {
            fatorial *= i; 
        }

        printf("O fatorial de %d (%d!) e: %llu\n", N, N, fatorial);
    }
	return 0;
}
