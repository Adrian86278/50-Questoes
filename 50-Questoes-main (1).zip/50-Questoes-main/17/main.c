#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
    int num, i;
    
    printf("Digite um numero para ver a sua tabuada: ");
    scanf("%d", &num);

    printf("\n--- Tabuada do %d ---\n", num);

    for (i = 1; i <= 10; i++) {
        printf("%d x %d = %d\n", num, i, num * i);
    }
	return 0;
}
