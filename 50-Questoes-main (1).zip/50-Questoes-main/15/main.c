#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int N, i;
	
	printf("Digite um numero inteiro positivo(N): ");
	scanf("%d", &N);
	
	if(N <= 0){
		printf("Por favor, Digite um numero maior que zero.\n");
	}else{
		printf("Numeros pares entre 1 e %d:\n",N);
		
		for (i = 1; i <= N; i++){
			if (i % 2 == 0){
				printf("%d ", i);
			}
		}
		printf("\n");
	}
	return 0;
}
