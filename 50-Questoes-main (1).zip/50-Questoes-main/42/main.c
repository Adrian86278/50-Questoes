#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	char resposta;

    do {
        printf("Deseja continuar? (S/N): ");
        scanf(" %c", &resposta);
        resposta = toupper(resposta);

        if (resposta != 'S' && resposta != 'N') {
            printf("Opcao invalida! Digite apenas S ou N.\n");
        }
    } while (resposta != 'S' && resposta != 'N');

    printf("%s\n", (resposta == 'S') ? "A operacao ira continuar." : "A operacao sera encerrada.");

	return 0;
}
