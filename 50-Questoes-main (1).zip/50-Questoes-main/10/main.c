#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
float num1, num2, resultado;
    char operacao;


    printf("Digite o primeiro numero: \n");
    scanf("%f", &num1);

    printf("Digite a operacao (+, -, * ou /): \n");
    scanf(" %c", &operacao); 

    printf("Digite o segundo numero: \n");
    scanf("%f", &num2);

    if (operacao == '+') {
        resultado = num1 + num2;
        printf("Resultado: %.2f\n", resultado);
    } 
    else if (operacao == '-') {
        resultado = num1 - num2;
        printf("Resultado: %.2f\n", resultado);
    } 
    else if (operacao == '*') {
        resultado = num1 * num2;
        printf("Resultado: %.2f\n", resultado);
    } 
    else if (operacao == '/') {

        if (num2 == 0) {
            printf("Erro: Nao e possivel dividir por zero!\n");
        } else {
            resultado = num1 / num2;
            printf("Resultado: %.2f\n", resultado);
        }
    } 
    else {
        printf("Operacao invalida!\n");
    }

    return 0;
}
