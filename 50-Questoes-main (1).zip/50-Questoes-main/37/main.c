#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	 float preco;
    float total = 0;
    int quantidade = 0;

    printf("Digite o preco do produto (0 para encerrar): ");
    scanf("%f", &preco);

    while (preco != 0) {

        if (preco > 0) {
            total = total + preco;
            quantidade++;
        } else {
            printf("Valor negativo ignorado!\n");
        }

        printf("Digite outro preco (0 para encerrar): ");
        scanf("%f", &preco);
    }

    printf("Quantidade de produtos: %d\n", quantidade);
    printf("Total da compra: R$ %.2f\n", total);

	return 0;
}
