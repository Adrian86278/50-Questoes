#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
int num1, num2;

printf("====Digite dois numeros pra saber qual o maior!====\n");

printf("Digite o primeiro numero: ");
scanf("%d", &num1);
printf("\ndigite o segundo numero:");
scanf("%d", &num2);

if (num1 > num2){
	printf("o primeiro numero e maior!");
}else if (num1 < num2){
	printf("\no segundo numero e maior!");
} else {
	printf("\nos dois sao iguais!");
}
	return 0;
}
