#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int N, i;
	
	printf("digite um numero inteiro positivo (N): ");
	scanf("%d", &N);
	
	if (N < 0) {
        printf("Por favor, digite um numero maior ou igual a zero.\n");
    } else {
        printf("Contagem regressiva de %d ate 0:\n", N);
        
        for (i = N; i >= 0; i--) {
            printf("%d ", i);
        }
        
        printf("\nFim da contagem!\n");
    }
	return 0;
}
