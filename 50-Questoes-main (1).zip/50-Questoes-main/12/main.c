#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int dia;
	
	printf("Digite um numero de 1 a 7: \n");
	scanf("%d", &dia);
	
	switch (dia){
		case 1:
			printf("Domingo\n");
			break;
		case 2:
			printf("Segunda\n");
			break;
		case 3:
			printf("terca\n");
			break;
		case 4:
			printf("quarta\n");
			break;
		case 5:
			printf("quinta\n");
			break;
		case 6:
			printf("sexta\n");
			break;
		case 7: 
			printf("sabado\n");
			break;
		default: 
			printf("Opcao invalida! Digite um numero de 1 a 7.\n");
			break;
	}
	return 0;
}
