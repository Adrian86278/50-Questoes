#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int senha_correta = 1234;
	int senha_digitada;
	
	printf("Digite a senha: ");
	scanf("%d", &senha_digitada);
	
	while (senha_digitada != senha_correta){
		printf("Senha incorret! digite novamente.\n");
		printf("Digite a senha: ");
		scanf("%d", &senha_digitada);
	}
	
	printf("\nAcesso permitido!\n");
	return 0;
}
