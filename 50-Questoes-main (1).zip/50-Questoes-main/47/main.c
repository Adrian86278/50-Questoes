#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	    int codigos[10];
    int codigoBusca;
    int indiceEncontrado = -1;
    int i;

    for (i = 0; i < 10; i++) {
        printf("Digite o %do codigo numerico: ", i + 1);
        scanf("%d", &codigos[i]);
    }

    printf("\nDigite o codigo que deseja buscar: ");
    scanf("%d", &codigoBusca);

    for (i = 0; i < 10; i++) {
        if (codigos[i] == codigoBusca) {
            indiceEncontrado = i;
            break;
        }
    }

    if (indiceEncontrado != -1) {
        printf("Codigo %d encontrado no indice %d (posicao %d).\n", codigoBusca, indiceEncontrado, indiceEncontrado + 1);
    } else {
        printf("Codigo %d nao encontrado no vetor.\n", codigoBusca);
    }

	return 0;
}
