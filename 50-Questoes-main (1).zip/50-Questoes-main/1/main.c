#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	int num, sucessor, antecessor;
	
	printf("Digite um numero: ");
	scanf("%d", &num);
	
	sucessor = num + 1;
	antecessor = num - 1;
	
	printf("Sucessor: %d\n", sucessor);
	printf("Antecessor: %d", antecessor);
	return 0;
}
