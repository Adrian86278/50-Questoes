	float num;
	float dub;
	float trip; 
	float meta;
	
	printf("Digite um numero: ");
	scanf("%f", &num);
	
	dub = num * 2;
	trip = num * 3;
	meta = num / 2;
	
	printf("Dobro: %.2f\n", dub);
	printf("triplo: %.2f\n", trip);
	printf("Metade: %.2f\n", meta);
