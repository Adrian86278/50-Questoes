#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float num;
	int i;
	int positivos = 0, negativos = 0, zeros = 0;
	
	printf("Digite 10 numeros:\n");
	
	for (i = 1; i < 10; i++){
		printf("Numero %d: ", i);
		scanf("%f",&num);
		
		if (num > 0){
			positivos++;
		}else if( num < 0){
			negativos++;
		}else{
			zeros++;
		}
	}
	
	printf("\n=== Resumo dos Resultados===\n");
	printf("Quantidade de numeros Positivos: %d\n", positivos);
	printf("Quantidade de numeros Negativos: %d\n", negativos);
	printf("Quantidade de numeros zeros: %d\n", zeros);
	return 0;
}
