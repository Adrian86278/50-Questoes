#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	 int opcao;

    printf("===== MENU DE ATENDIMENTO =====\n");
    printf("1 - Suporte tecnico\n");
    printf("2 - Financeiro\n");
    printf("3 - Comercial\n");
    printf("4 - Cancelamento\n");

    printf("Escolha uma opcao: ");
    scanf("%d", &opcao);

    switch (opcao) {

        case 1:
            printf("Encaminhado para Suporte Tecnico\n");
            break;

        case 2:
            printf("Encaminhado para Financeiro\n");
            break;

        case 3:
            printf("Encaminhado para Comercial\n");
            break;

        case 4:
            printf("Encaminhado para Cancelamento\n");
            break;

        default:
            printf("Opcao invalida\n");
    }
	return 0;
}
