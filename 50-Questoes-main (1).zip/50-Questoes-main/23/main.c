#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
    float num, maior;
    int i;

    printf("Digite 10 numeros:\n");
    
    for (i = 1; i <= 10; i++) {
        printf("Numero %d: ", i);
        scanf("%f", &num);

        if (i == 1) {
            maior = num;
        } 
        else if (num > maior) {
            maior = num;
        }
    }

    printf("\n--- Resultado ---\n");
    printf("O maior numero digitado foi: %.2f\n", maior);

    return 0;
}


